import java.util.Scanner;

public class WizardsMirror {
    static String reverseString(String s, int i) {
        if (i < 0) return "";
        return s.charAt(i) + reverseString(s, i - 1);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.next();
        System.out.println(reverseString(s, s.length() - 1));
    }
}
